<?php 

?>
<div class="formtemp_sec">
	<form method="post" action="" id="booking_vehicle_form">
		<input type="hidden" name="post_id" id="post_id" class="form-control">
		<div class="form-group">
				<label class="form-lables">Client API ID:</label>
				<input type="text" name="client_api_id" id="client_api_id" class="form-control" required="required">
	    </div>

	    <div class="form-group">
			<label class="form-lables">Client Secret:</label>
			<input type="text" name="client_secret" id="client_secret" class="form-control" required="required">
	    </div>

	    <div class="form-group">
	    	<button type="submit" class="btn btn-default admin_frm_btn" id="admin_frm_btn">Save</button>	
	    </div>
	</form>

	<div class="alert alert-success alert_info" id="success_msg">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		<span></span>
	</div>

	<div class="alert alert-danger alert_info" id="error_msg">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		<span></span>
	</div>
</div>