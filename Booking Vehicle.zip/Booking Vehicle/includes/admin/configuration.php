<?php 

?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<h1>Booking Vehicle</h1>
			<div class="adminform_sec">				
				<div class="shortcode_info_sec" id="shortcode_info_sec">
					<h3>Use this shortcode on post</h3>
					<h3><strong>[bookingvehicle]</strong></h3>
				</div>			
				
			</div>
		</div>
	</div>
</div>