<?php 
/**
 * @package Booking Vehicle
 * @version 1.0
 */
/*
Plugin Name: Booking Vehicle
Plugin URI: 
Description: This is Booking Vehicle
Author: Swapnil Patil
Version: 1.0
Author URI: 
Licence:
Text-domain:Booking Vehicle
*/

if(!class_exists('bookingvehicle_class')){
	if( !defined( 'ABSPATH' ) ) {
		die;
	}

	class bookingvehicle_class{

		function __construct()
		{
			add_action('admin_menu', array($this,'bookingvehicle_submenu_page'));
			register_activation_hook(__FILE__, array($this,'fn_bookingvehicle_activate'));
			register_deactivation_hook( __FILE__, array($this,'fn_delete_tblpl'));
			add_action('admin_enqueue_scripts', array($this, 'inc_setting_all_scripts'));
			add_action('wp_enqueue_scripts', array($this, 'inc_front_scripts'));
			/*add_action( "wp_ajax_submit_verifyKeysform", array($this,"submit_verifyKeysform" ));
			add_action( "wp_ajax_nopriv_submit_verifyKeysform", array($this,"submit_verifyKeysform" ));	*/
			add_shortcode('bookingvehicle', array($this, 'bookingvehicle_shortcode'));
			add_action( 'add_meta_boxes',  array($this, 'booking_meta_box_add'));
		}

		function fn_bookingvehicle_activate(){
			global $wpdb;
			$table_name = $wpdb->prefix . 'bookingvehicle';
			$charset_collate = $wpdb->get_charset_collate();
			$sql = "CREATE TABLE $table_name (
				id mediumint(9) NOT NULL AUTO_INCREMENT,
				first_name varchar(200) NOT NULL,
				last_name varchar(200) NOT NULL,
				email varchar(200) NOT NULL,
				phone varchar(200) NOT NULL,
				vehicle_type varchar(200) NOT NULL,
				vehicle_price varchar(200) NOT NULL,
				status varchar(200) NOT NULL,
				created_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY  (id)
			) $charset_collate;";

			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );
		}

		function fn_delete_tblpl(){
			global $wpdb;
			$table_name = $wpdb->prefix . 'bookingvehicle';
			$sql = "DROP TABLE IF EXISTS $table_name";
			$wpdb->query($sql);
			delete_option("my_plugin_db_version");
		}
		function inc_setting_all_scripts(){
			wp_register_style( 'BookingvehicleStyleAdmin', plugins_url( '/assets/css/admin.css', __FILE__ ));
			wp_enqueue_style( 'BookingvehicleStyleAdmin');
	
			wp_enqueue_script( 'BookingvehicleScript', plugins_url( '/assets/js/jquery.min.js', __FILE__ ));
			wp_enqueue_script( 'BookingvehicleScript', plugins_url( '/assets/js/admin.js', __FILE__ ));

			$params = array(
				'ajaxurl' => admin_url( 'admin-ajax.php'),
			);
			wp_localize_script( 'BookingvehicleScript', 'script_params', $params );
		}

		function inc_front_scripts(){
			wp_register_style( 'BookingvehicleStyleFront', plugins_url( '/assets/css/front_style.css', __FILE__ ));
			wp_enqueue_style( 'BookingvehicleStyleFront');
		}

		function bookingvehicle_submenu_page(){
			add_menu_page('Booking Vehicle', 'Booking Vehicle', 'manage_options', 'booking_vehicle', array($this,'fn_booking_vehicle_output') );	
		}

		function fn_booking_vehicle_output(){
			require_once( plugin_dir_path( __FILE__ ). '/includes/admin/configuration.php');
		}

		function booking_meta_box_add()
		{
			add_meta_box(
			       'custom_meta_box-2',       // $id
			       'Dauer2',                  // $title
			       'show_custom_meta_box_2',  // $callback
			       'project',                 // $page
			       'normal',                  // $context
			       'high'                     // $priority
			   );		
		}

		function show_custom_meta_box_2()
		{
			global $post;

    // Use nonce for verification to secure data sending
    wp_nonce_field( basename( __FILE__ ), 'wpse_our_nonce' );

    ?>

    <!-- my custom value input -->
    <input type="number" name="wpse_value" value="">

    <?php
		}

		function bookingvehicle_shortcode(){
			global $wpdb;
			$dhtml = "";

			$categories = get_the_category();
			//echo "<pre>";print_r($categories);

			$dhtml .= '<div class="formtemp_sec">
						<form method="post" action="" id="booking_vehicle_form">
							<input type="hidden" name="post_id" id="post_id" class="form-control">
							<div class="form-group">
									<label class="form-lables">First Name:</label>
									<input type="text" name="first_name" id="first_name" class="form-control" required="required">
						    </div>

						    <div class="form-group">
								<label class="form-lables">Last Name:</label>
								<input type="text" name="last_name" id="last_name" class="form-control" required="required">
						    </div>

						    <div class="form-group">
								<label class="form-lables">Email:</label>
								<input type="text" name="email" id="email" class="form-control" required="required">
						    </div>

						    <div class="form-group">
								<label class="form-lables">Phone:</label>
								<input type="text" name="phone" id="phone" class="form-control" required="required">
						    </div>

						    <div class="form-group">
								<label class="form-lables">Vehice Type:</label>
								<select name="vehicle_type" id="vehicle_type" class="form-control" required="required">
									<option value="">Select Option</option>';
									foreach($categories as $key => $value){
										$dhtml .= '<option value="'.$value->term_id.'">'.$value->name.'</option>';
									}
								$dhtml .= '</select>
						    </div>

						    <div class="form-group">
								<label class="form-lables">Vehice Price:</label>
								<input type="text" name="vehicle_price" id="vehicle_price" class="form-control" required="required" readonly="true">
						    </div>

						    <div class="form-group">
						    	<button type="submit" class="btn btn-default booking_frm_btn" id="booking_frm_btn">Save</button>	
						    </div>
						</form>

						<div class="alert alert-success alert_info" id="success_msg">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<span></span>
						</div>

						<div class="alert alert-danger alert_info" id="error_msg">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<span></span>
						</div>
					</div>';
			return $dhtml;
		}
		/*function submit_verifyKeysform(){
			global $wpdb;

			$record_id = $_POST['record_id'];
			$client_api_id = $_POST['client_api_id'];
			$client_secret = $_POST['client_secret'];
			$response = array();

			if(!empty($client_api_id) && !empty($client_secret)){

				if(!empty($record_id)){
					$table_name = $wpdb->prefix.'pverify_pl';
					$wpdb->query($wpdb->prepare("UPDATE $table_name SET client_api_id='$client_api_id', client_secret='$client_secret' WHERE id = $record_id"));
					$response['status'] = "success";
					$response['msg'] = "Details updated successfully!!";
				}else{
					
					$table_name = $wpdb->prefix.'pverify_pl';
					$tbl_data = array(		
						'client_api_id' => $client_api_id,		
						'client_secret' => $client_secret,
					);
					
					$insertq = $wpdb->query("INSERT INTO ".$table_name." (client_api_id, client_secret) VALUES ('$client_api_id', '$client_secret')"  );
					if($insertq){
						$response['status'] = "success";
						$response['msg'] = "Details saved successfully!!";
					}else{
						$response['status'] = "failed";
						$response['msg'] = "Details not saved!";
					}
				}
			}else{
				$response['status'] = "failed";
				$response['msg'] = "All details are required!";
			}

			die(json_encode($response));
		}

		*/
	}
}

$obj_pverify = new bookingvehicle_class;
?>